# Challenge API v6

A modern Challenge Management API built with Node.js, Express, Prisma ORM, and PostgreSQL. This API provides comprehensive CRUD operations for managing challenges with advanced features like source tracking, filtering, and pagination.

## Features

- **Modern Tech Stack**: Node.js, Express.js, Prisma ORM, PostgreSQL
- **Challenge Source Tracking**: Track challenge origins (Work Manager, Topgear, Github, etc.)
- **Comprehensive CRUD Operations**: Create, Read, Update, Delete challenges
- **Advanced Filtering**: Filter by status, type, track, challengeSource, and more
- **Pagination Support**: Efficient pagination with metadata
- **Data Validation**: Input validation with detailed error messages
- **API Documentation**: Interactive Swagger/OpenAPI documentation
- **Error Handling**: Comprehensive error handling with detailed responses
- **Type Safety**: Prisma ORM ensures type-safe database operations

## Quick Start

### Prerequisites

- Node.js (v14 or higher)
- PostgreSQL database
- npm or yarn package manager

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd challenge-api-v6
